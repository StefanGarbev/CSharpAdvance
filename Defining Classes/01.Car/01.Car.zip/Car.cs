﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManufacturer
{
    public class Car
    {
        private string marke;
        private string model;
        private int year;

        //public Car()
        //{
        //    Marke = marke;
        //    Model = model;
        //    Year = year;
        //}

        public string  Marke { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
    }
}
